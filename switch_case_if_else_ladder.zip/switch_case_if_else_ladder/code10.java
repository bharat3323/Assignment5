class Real {
	public static void main(String[] args) {
		int fee = 5000;
		if(fee==5000) {
			System.out.println("Admission request is accepted");
		}else if(fee<5000 && fee>0) {
			System.out.println("admission will cancel soon ");
		}else if(fee<10000) {
			System.out.println("Pay the complete fees as soon as posible");
		}else if(fee==10000) {
			System.out.println("You are eligible for the course");
		}else{
			System.out.println("Invalid input");
		}
	}
}
