class Student{
	public static void main(String[] args) {
		int m1 = 60;
		int dsa = 61;
		int cg = 62;
		int deld = 67;
		int ai = 65;
		int sum = m1+dsa+cg+deld+ai;
		if(m1>=35 && dsa>=35 && cg>=35 && deld>=35 && ai>=35) {
			System.out.println(sum);
		}else{
			System.out.println("Failed");
		}
	}
}
