class Remark{
	public static void main(String[] args) {
		char ch = 'O';
		if(ch=='O'){
			System.out.println("outstanding");
		}else if(ch=='A'){
			System.out.println("Pass with Distinction");
		}else if(ch=='B'){
			System.out.println("Pass");
		}else if(ch=='F'){
			System.out.println("Fail");
		}else{
			System.out.println("Invalid input");
		}
	}
}

