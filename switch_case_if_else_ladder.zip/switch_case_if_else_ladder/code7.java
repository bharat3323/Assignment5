class Planner {
	public static void main(String[] args) {
		int budget = 10000;
		switch(budget){
			case 15000:
                                System.out.println("Jammu & Kashmir");
                                break;
			case 10000:
                                System.out.println("Manali");
                                break;
			case 6000:
                                System.out.println("Amritsar");
                                break;
			case 2000:
                                System.out.println("Mahabaleshwar");
                                break;
			default:
				System.out.println("for other budget try next time");
		}
	}
}
