class Size{
        public static void main(String[] args) {
                char ch = 'S';
                if(ch=='S'){
                        System.out.println("Small");
                }else if(ch=='M'){
                        System.out.println("Medium");
                }else if(ch=='L'){
                        System.out.println("Large");
                }else{
                        System.out.println("Invalid input");
                }
        }
}

