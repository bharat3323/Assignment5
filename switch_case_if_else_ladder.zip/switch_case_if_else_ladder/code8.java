class Multiply {
	public static void main(String[] args) {
		int num1 = 50;
		int num2 = 3;
		int mul = num1*num2;
		if(num1>0 && num2>0){
			System.out.println(num1*num2);
		}else{
			System.out.println("Sorry Negative numbers cannot be allowed");
		}
		switch(mul%2){
			case 1:
				System.out.println("number is negative");
				break;
			case 0:
				System.out.println("number is negative");
				break;
			default:
				System.out.println("invalid");
		}
	}
}
