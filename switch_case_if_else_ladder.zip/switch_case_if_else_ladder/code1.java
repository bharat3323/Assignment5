 class Even{
	 public static void main(String[] args){
		 int num = 45;
		 if(num%2==0){
			 System.out.println("number is Even");
		 }else{
			 System.out.println("number is odd");
		 }
	 }
 }

